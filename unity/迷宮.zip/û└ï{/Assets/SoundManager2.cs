using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager2 : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip audioClip;

    // 再生したい効果音のインデックスを指定して再生する関数
    public void PlaySound()
    {
        audioSource.clip = audioClip;
        audioSource.Play();
    }
    
    public void StopSound()
    {
        if (audioSource.isPlaying)
        {
            audioSource.Stop();
        }
    }
}
